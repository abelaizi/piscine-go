package piscine

func Enigma(a ***int, b *int, c *******int, d ****int) {
	fix := ***a
	***a = *b
	*b = ****d
	****d = *******c
	*******c = fix
}
